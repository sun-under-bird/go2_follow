"""本机跟随演示入口：物理仿真、ROS 控制节点与可视化面板。"""
import argparse
import fcntl
import os
from pathlib import Path
import signal
import threading
import time
from typing import Literal, Optional
from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse, Response
from pydantic import BaseModel, Field, model_validator
import rclpy
from rclpy.executors import SingleThreadedExecutor
import uvicorn
from .simulation import ROOT, Simulation
from .ros_nodes import SensorBridge, FollowerNode, Telemetry
from .mppi_runtime import MppiRuntime


class Command(BaseModel):
    """限定页面可执行的仿真操作及目标活动范围。"""
    action: Literal['resume', 'pause', 'estop', 'reset', 'signal_on', 'signal_off', 'hold', 'straight', 'circle', 'waypoint', 'speed',
                    'scenario', 'route', 'confirm_clearance', 'depth_on', 'depth_off']
    scenario: Optional[Literal['open', 'long_wall', 'consecutive', 'corner', 'blocked']] = None
    x: Optional[float] = Field(default=None, ge=-18, le=18, allow_inf_nan=False)
    y: Optional[float] = Field(default=None, ge=-18, le=18, allow_inf_nan=False)
    speed: Optional[float] = Field(default=None, ge=0.05, le=0.70, allow_inf_nan=False)

    @model_validator(mode='after')
    def require_waypoint(self):
        """地图目标必须包含完整坐标，避免不完整输入进入物理线程。"""
        if self.action == 'waypoint' and (self.x is None or self.y is None):
            raise ValueError('地图目标需要 x、y 坐标')
        if self.action == 'scenario' and self.scenario is None:
            raise ValueError('场景切换需要选择场景')
        return self


class Runtime:
    """管理本次演示拥有的线程与 ROS 节点，退出时统一释放。"""
    def __init__(self, render=True, execution_mode='heading'):
        """创建模拟器和两个 ROS 节点，控制器没有对模拟器的直接引用。"""
        self.telemetry = Telemetry()
        self.simulation = Simulation(render=render, execution_mode=execution_mode)
        rclpy.init()
        self.bridge = SensorBridge(self.simulation, self.telemetry)
        self.follower = FollowerNode()
        self.mppi = MppiRuntime()
        self.executor = SingleThreadedExecutor()
        self.executor.add_node(self.follower)
        # 传感器桥独立调度，导航处理深度时仍能发布新里程计和接收最终速度。
        self.sensor_executor = SingleThreadedExecutor()
        self.sensor_executor.add_node(self.bridge)
        self.ros_thread = threading.Thread(target=self.executor.spin, name='go2-ros', daemon=True)
        self.sensor_thread = threading.Thread(target=self.sensor_executor.spin, name='go2-sensors', daemon=True)
        self.ros_thread.start()
        self.sensor_thread.start()
        self.simulation.start()
        try:
            self.mppi.start()
        except Exception:
            self.close()
            raise

    def close(self):
        """先停物理步进，再停通信，避免留下仍执行旧命令的模拟器。"""
        simulation_error = None
        try:
            self.simulation.close()
        except Exception as error:
            # 渲染线程超时也要继续清专属 ROS/Nav2 资源，再让进程明确失败退出。
            simulation_error = error
        self.executor.shutdown(timeout_sec=5)
        self.sensor_executor.shutdown(timeout_sec=5)
        self.ros_thread.join(timeout=5)
        self.sensor_thread.join(timeout=5)
        # ROS 不再接入结果后，等待唯一深度工作线程退出，再释放导航器。
        self.follower.close_depth_worker()
        self.follower.core.close()
        self.mppi.close()
        self.bridge.destroy_node()
        self.follower.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()
        self.telemetry.close()
        if simulation_error is not None:
            raise simulation_error


def make_app(runtime):
    """创建仅绑定本机的 HTTP 页面、图像、操作和日志接口。"""
    app = FastAPI(title='Go2 平地有限视野跟随演示')

    @app.get('/')
    def index():
        """返回无外部 CDN 依赖的本地可视化页面。"""
        return FileResponse(Path(__file__).parent / 'static/index.html')

    @app.get('/api/state')
    def state():
        """返回当前物理状态、控制诊断及曲线数据。"""
        payload = runtime.telemetry.read()
        # 模式启动后固定，不能在运行中切换而保留另一模式的航向与历史状态。
        with runtime.simulation.lock:
            execution = dict(runtime.simulation.snapshot.get('execution', {}))
        payload.update(app_id='go2_follow_demo', ros_alive=runtime.ros_thread.is_alive() and runtime.sensor_thread.is_alive(), physics_alive=not runtime.simulation.quit.is_set(),
                       execution_mode=runtime.simulation.policy.yaw_mode, execution=execution,
                       mppi_alive=all(p.poll() is None for p in runtime.mppi.processes),
                       error=runtime.simulation.error or runtime.simulation.render_error or payload.get('error') or
                       (None if all(p.poll() is None for p in runtime.mppi.processes) else 'Nav2 MPPI 子进程退出，请查看 mppi 日志'))
        return payload

    @app.get('/api/frame/{name}')
    def frame(name: Literal['left', 'right', 'scene']):
        """读取已渲染的 JPEG，不在请求线程创建额外 OpenGL 上下文。"""
        with runtime.simulation.lock:
            data = runtime.simulation.images.get(name)
        if data is None:
            return Response(status_code=204)
        return Response(data, media_type='image/jpeg', headers={'Cache-Control': 'no-store'})

    @app.post('/api/command')
    def command(request: Command):
        """把经过边界验证的人工操作提交给仿真场景。"""
        if runtime.simulation.error:
            raise HTTPException(409, '物理线程异常，请查看日志并重启演示')
        runtime.simulation.action(request.action, request.x, request.y, request.speed, request.scenario)
        return {'ok': True, 'action': request.action}

    @app.get('/api/log.csv')
    def download_log():
        """导出记录的固定快照，避免写入中的文件改变 HTTP 响应长度。"""
        content = runtime.telemetry.download_log()
        return Response(content, media_type='text/csv',
                        headers={'Content-Disposition': f'attachment; filename="{runtime.telemetry.path.name}"'})

    @app.post('/api/shutdown')
    def shutdown():
        """先停止跟随，再结束本次演示服务。"""
        runtime.simulation.action('estop')
        threading.Timer(0.3, lambda: os.kill(os.getpid(), signal.SIGINT)).start()
        return {'ok': True}

    return app


def main():
    """启动独占的本机仿真实例；同一用户不可同时启动两个演示控制器。"""
    parser = argparse.ArgumentParser(description='Go2 平地有限视野跟随演示')
    parser.add_argument('--port', type=int, default=8765)
    parser.add_argument('--no-render', action='store_true', help='仅供无图形的自动化检查使用')
    parser.add_argument('--execution-mode', choices=('heading', 'velocity'), default='heading',
                        help='独立执行模式对照；只改变角速度输入生成，不改规划和安全门槛')
    arguments = parser.parse_args()
    lock = (ROOT / 'follow_demo/runtime.lock').open('w')
    try:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError:
        raise SystemExit('跟随演示已经运行，请打开 http://localhost:8765')
    runtime = Runtime(render=not arguments.no_render, execution_mode=arguments.execution_mode)
    try:
        print(f'Go2 跟随演示：http://localhost:{arguments.port}，执行模式：{arguments.execution_mode}，日志：{runtime.telemetry.path}', flush=True)
        uvicorn.run(make_app(runtime), host='127.0.0.1', port=arguments.port, log_level='warning', access_log=False)
    finally:
        runtime.close()
        lock.close()


if __name__ == '__main__':
    main()
