"""跨搜索、控制与终点判断共享的仿真配置，不代表实机标定参数。"""

# 搜索的舒适距离带与 MPPI 位置容差必须一起用于上层到达判定。
# 否则控制器已到终点，上层仍催促前进，会不断重发厘米级路径。
FOLLOW_REGION_HALF_WIDTH = .22
FOLLOW_GOAL_TOLERANCE = .08
# 该距离只用于参考点接近及无收益终点的失败判定；观察准入由实际位置的区域与视野验证决定。
OBSERVATION_POSITION_TOLERANCE = FOLLOW_GOAL_TOLERANCE
OBSERVATION_YAW_TOLERANCE = .20
