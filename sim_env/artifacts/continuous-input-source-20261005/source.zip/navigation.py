"""静态平地连续跟随：异步通道搜索、Nav2 MPPI 输入和统一执行保护。"""
import copy
import math
import time
from concurrent.futures import ThreadPoolExecutor
import numpy as np
from .controller import FollowController, clamp
from .local_map import RollingMap
from .local_planner import LocalPlanner, Plan
from .navigation_config import FOLLOW_REGION_HALF_WIDTH, FOLLOW_GOAL_TOLERANCE, MAX_NAVIGATION_TURN
from .observation import ObservationSession
from .follow_intent import FollowIntent, TrailReferenceTracker


class NavigationController(FollowController):
    """控制线程持有地图，搜索读取副本，MPPI 只提供待检查的候选命令。"""
    def __init__(self, use_follow_intent=False, use_camera_observation=False):
        """明确使用静态历史地图；不将盲区历史证据当作动态侵入安全保证。"""
        super().__init__()
        self.grid = RollingMap(static_history=True)
        self.grid.camera_observation = bool(use_camera_observation)
        self.planner, self.plan = LocalPlanner(), Plan()
        self.pool = ThreadPoolExecutor(max_workers=1, thread_name_prefix='follow-search')
        self.future = None
        self.last_plan, self.plan_ms, self.plan_revision = -math.inf, 0., 0
        self.minimum_plan_stamp = -math.inf
        self.motion, self.phase = (0., 0., 0.), 'FOLLOWING'
        self.stall_since, self.progress_pose = None, None
        self.progress_failed = False
        self.observing_since = None
        self.safety_path, self.footprint = [], {}
        self.depth_timeout, self.code = .9, 'WAITING'
        self.confirmation_requested = False
        self.external_command, self.external_stamp = (0., 0.), -math.inf
        self.external_active = False
        self.speed_limit, self.safety_limited = 0., False
        self.tracking_requested = False
        self.observation = ObservationSession()
        self.rejected_plan_count,self.rejected_plan_reason = 0,''
        self.guard_diagnostic = {}
        self.trajectory_diagnostic = {}
        self.halt_counts, self.halt_events = {}, []
        self.use_follow_intent = bool(use_follow_intent)
        # 保留旧规划器 1.2 s 前视，另容纳至多 0.2 s 有效采样年龄。
        # 预测只形成有限意图；其未知区域和拐角仍须经过地图搜索与执行保护。
        self.follow_intent = FollowIntent(max_prediction=1.4) if self.use_follow_intent else None
        self.intent_tracker = TrailReferenceTracker() if self.use_follow_intent else None
        self.intent_reference = None
        self.intent_diagnostic = dict(enabled=self.use_follow_intent, status='WAITING')

    def observe(self, local_x, local_y, stamp):
        """旧 UWB 门控成功后才记录世界轨迹，不重复加入控制周期中的目标外推点。"""
        accepted = super().observe(local_x, local_y, stamp)
        if accepted and self.use_follow_intent:
            pose = self.history.at(stamp)
            self.follow_intent.update(self.last_world_measurement, stamp,
                                      robot_position=(pose.x, pose.y), velocity=self.target_velocity)
        return accepted

    def prepare_intent_reference(self, now, pose, spacing):
        """在控制线程形成不可变参考，异步搜索只能读取本次快照，不能改变轨迹进展。"""
        if not self.use_follow_intent:
            return None
        guide = self.follow_intent.guide(now, prediction_horizon=1.2)
        reference = self.intent_tracker.build(guide, spacing, (pose.x, pose.y))
        self.intent_reference = reference
        self.intent_diagnostic = dict(enabled=True, history=self.follow_intent.diagnostics())
        if reference is None:
            self.intent_diagnostic['status'] = 'TARGET_INVALID'
        else:
            self.intent_diagnostic.update(reference.diagnostics(), latest_target=list(guide.latest_target),
                                          predicted_target=list(guide.predicted_target))
        return reference

    def close(self):
        """等待唯一搜索任务退出，重置场景不能遗留后台搜索。"""
        self.pool.shutdown(wait=True, cancel_futures=True)

    def confirm_start(self, now):
        """只在里程计新鲜时接受本轮一次起始净空确认。"""
        if not self.history.values or not 0 <= now-self.history.values[-1].t <= .2:
            return False
        pose = self.history.values[-1]
        return self.grid.confirm_start(pose.x, pose.y, now)

    def halt(self, state, code, reason, now=None):
        """统一清空输出和舒适性积分，硬保护优先于速度平滑。"""
        if self.state != state or self.code != code:
            stamp = self.last_tick if now is None else now
            pose_stamp = self.history.values[-1].t if self.history.values else None
            self.halt_counts[code] = self.halt_counts.get(code, 0) + 1
            # 只记录状态进入事件；页面约 5 Hz，仍能看到两次刷新之间发生的短暂失效。
            event = dict(t=stamp, state=state, code=code,
                         odom_age=None if stamp is None or pose_stamp is None else stamp-pose_stamp,
                         depth_age=None if stamp is None or self.grid.last_depth is None else stamp-self.grid.last_depth,
                         controller_age=None if stamp is None or not math.isfinite(self.external_stamp) else stamp-self.external_stamp)
            self.halt_events = (self.halt_events + [event])[-32:]
        self.code, self.safety_path = code, []
        if state in ('PAUSED','ESTOP','INITIALIZING','TARGET_LOST','ODOM_LOST','INPUT_LOST') or code == 'MAP_STALE':
            self.tracking_requested = False
            if self.plan.kind == 'OBSERVING' or self.observation.plan is not None or self.use_follow_intent:
                self.invalidate_plan(code,now)
                if self.use_follow_intent:
                    # 同一控制时刻提交又被中断的旧搜索也必须拒收，不能仅靠普通结果年龄门槛。
                    stamp = self.last_tick if now is None else now
                    if stamp is not None:
                        self.minimum_plan_stamp = max(self.minimum_plan_stamp, math.nextafter(stamp, math.inf))
            if self.use_follow_intent:
                self.intent_reference = None
                self.intent_diagnostic = dict(enabled=True, status=code)
                if state == 'TARGET_LOST':
                    self.follow_intent.update(None, None, valid=False)
                elif state in ('PAUSED', 'ESTOP') and self.state != state:
                    # 明确暂停可重新建立起始意图，恢复时不要求追赶已经被有限历史删除的转角。
                    self.follow_intent.reset()
                    self.intent_tracker.reset()
        return self.stop(state, reason)

    def invalidate_plan(self, reason, now=None):
        """同时撤销观察任务、执行路径及旧候选，恢复输入后不能继续无上下文的观察移动。"""
        self.observation.clear()
        self.plan = Plan(reason=reason)
        self.plan_revision += 1
        self.external_active,self.external_stamp = False,-math.inf
        self.last_plan = -math.inf
        stamp = self.last_tick if now is None else now
        if stamp is not None:
            self.minimum_plan_stamp = max(self.minimum_plan_stamp,stamp)
        # 正在搜索的旧任务可能无法取消；返回时仍按上述时间边界丢弃。
        if self.future is not None and self.future.cancel():
            self.future = None

    def compute_plan(self, snapshot, pose, target, velocity, spacing, requested, tried, intent_reference=None):
        """只读取地图副本；搜索耗时不会阻塞控制与 ROS 输入回调。"""
        start = time.monotonic()
        if self.use_follow_intent and intent_reference is None:
            # 试验身份不能在缺少新鲜意图时悄悄退回当前点圆环，否则会重现换边根因。
            return Plan(reason='FOLLOW_TRAIL_INVALID'), (time.monotonic()-start)*1000, requested
        _, allowed, clearance = snapshot.layers(pose.t)
        # 完整包络仍是硬门槛；额外舒适净空在搜索代价中表达。
        # 将舒适余量也当硬门槛，会切断到已验证前沿观察点的通道并原地自锁。
        plan = self.planner.search(snapshot, allowed, clearance, pose, target, velocity, spacing, tried,
                                   intent_reference=intent_reference)
        return plan, (time.monotonic()-start)*1000, requested

    def update_plan(self, pose, target, velocity, spacing, now, parking_safe=True, intent_reference=None):
        """只允许一个搜索，过旧结果丢弃；新地图仍需重新验证执行路径。"""
        outcome = self.observation.advance(pose,now,self.grid,parking_safe=parking_safe)
        if outcome in ('OBSERVATION_ORIENT','OBSERVATION_REGION_LEFT'):
            self.plan = copy.deepcopy(self.observation.plan)
            self.plan_revision += 1
            # 旧候选来自移动任务，不能穿过阶段切换继续驱动固定位置的观察动作。
            self.external_active,self.external_stamp = False,-math.inf
        elif outcome is not None and self.observation.plan is None:
            self.invalidate_plan(outcome,now)
        if self.future is not None and self.future.done():
            plan, self.plan_ms, stamp = self.future.result()
            self.future = None
            if self.minimum_plan_stamp <= stamp <= now and now-stamp < .8:
                _,allowed,_ = self.grid.layers(now)
                active = self.observation.plan is not None and bool(self.path_ahead(pose,allowed))
                # 搜索读取的是过去的快照，返回时先校验当前连接和整条路线，再提交任务。
                # 先 begin 再发现 PATH_INVALID，会清掉有效旧任务并反复创建无效观察动作。
                candidate_valid = not plan.path or bool(self.path_ahead(pose,allowed,plan))
                if not candidate_valid:
                    self.rejected_plan_count += 1
                    self.rejected_plan_reason = 'RETURNED_PATH_INVALID'
                # 优先接入已打开的跟随通道；观察姿态只有任务完成、明确失败或地图冲突才替换。
                if candidate_valid and (plan.kind == 'FOLLOWING' or not active):
                    excluded = (plan.kind == 'OBSERVING' and plan.path
                                and self.observation.excluded(plan.path[-1],plan.look_yaw,self.grid.resolution))
                    if not excluded:
                        self.observation.clear()
                        if plan.kind == 'OBSERVING':
                            self.observation.begin(plan,pose,now,self.grid)
                        self.plan,self.plan_revision = copy.deepcopy(plan),self.plan_revision+1
        if self.future is None and now-self.last_plan >= .4:
            self.last_plan = now
            self.future = self.pool.submit(self.compute_plan, copy.deepcopy(self.grid), copy.copy(pose),
                                           target.copy(), list(velocity), spacing, now,copy.deepcopy(self.observation.tried),
                                           intent_reference)

    def path_ahead(self, pose, allowed, plan=None):
        """裁去已经过的路径，连接前方路径，禁止回头追旧起点或跨障碍抄近路。"""
        plan = self.plan if plan is None else plan
        if not plan.path:
            return []
        dense = [plan.path[0]]
        for a,b in zip(plan.path,plan.path[1:]):
            dense.extend(np.linspace(a,b,max(2,int(math.dist(a,b)/.08)+1))[1:].tolist())
        here = [pose.x,pose.y]
        nearest = min(range(len(dense)),key=lambda i: math.dist(here,dense[i]))
        index = min(nearest+3,len(dense)-1)
        while index > nearest and not self.grid.segment_clear(allowed,here,dense[index]):
            index -= 1
        if not self.grid.segment_clear(allowed,here,dense[index]):
            return []
        route = [here]+dense[index:]
        if not all(self.grid.segment_clear(allowed,a,b) for a,b in zip(route,route[1:])):
            return []
        return route

    def braking_safe(self, pose, command, allowed, actual=False):
        """组合实测残余运动与候选指令检查停车，不能假定请求转向已经建立。"""
        v,w = command
        if actual:
            result = self.braking_trajectory(pose,v,w,self.motion[1],allowed)
            self.guard_diagnostic = dict(t=pose.t,kind='actual_motion',safe=result[0],
                                         check=dict(self.trajectory_diagnostic))
            return result
        if abs(v)+abs(w) < 1e-9:
            # 全零是制动请求，机身仍会移动；原来只预测零轨迹会掩盖残余运动。
            return self.braking_trajectory(pose,self.motion[0],self.motion[2],self.motion[1],allowed)
        forward = max(v,max(0.,self.motion[0]))
        turns = dict.fromkeys((w,self.motion[2],.5*(w+self.motion[2])))
        primary = []
        for turn in turns:
            safe,route = self.braking_trajectory(pose,forward,turn,self.motion[1],allowed)
            if not safe:
                return False,route
            if not primary:
                primary = route
        # 三种组合补上已知响应失配，不冒充覆盖全部过冲/时延的实机可达轨迹管。
        return True,primary

    def braking_trajectory(self, pose, v, w, lateral, allowed):
        """检查一组前速、转速与侧移的保持/制动过程，包含每步之间的全部触碰格。"""
        x,y,yaw = pose.x,pose.y,pose.yaw
        route = [[x,y]]
        stamp = pose.t if self.grid.last_depth is None else self.grid.last_depth
        latency = .25+min(.5,max(0,pose.t-stamp))
        duration = latency+max(abs(v)/.45,abs(w),abs(lateral)/.45)
        self.trajectory_diagnostic = dict(forward=v,turn=w,lateral=lateral,hold_s=latency,
                                          duration_s=duration,safe=True)
        for index in range(max(1,math.ceil(duration/.04))):
            if index*.04 >= latency:
                v = math.copysign(max(0,abs(v)-.45*.04),v)
                lateral = math.copysign(max(0,abs(lateral)-.45*.04),lateral)
                w = math.copysign(max(0,abs(w)-.04),w)
            x += (v*math.cos(yaw)-lateral*math.sin(yaw))*.04
            y += (v*math.sin(yaw)+lateral*math.cos(yaw))*.04
            yaw += w*.04
            if not self.grid.segment_clear(allowed,route[-1],[x,y]):
                self.trajectory_diagnostic.update(safe=False,first_rejected_segment=[route[-1],[x,y]],
                                                  elapsed_s=(index+1)*.04)
                return False,route
            route.append([x,y])
        return True,route

    def constrain_command(self, pose, original, allowed):
        """前进受限时保留仍安全的转向，每个候选重复校验完整停车过程。"""
        candidates = [(original[0]*scale,original[1]) for scale in (1.,.75,.5,.25,0.)]
        candidates += [(0.,original[1]*.5),(0.,0.)]
        rejected = []
        for command in candidates:
            safe,route = self.braking_safe(pose,command,allowed)
            if safe:
                # 只保存本拍的候选拒收证据；诊断不反向改变碰撞边界或放宽门槛。
                self.guard_diagnostic = dict(t=pose.t,kind='candidate',requested=list(original),
                                             accepted=list(command),rejected=rejected,safe=True)
                return command,route
            rejected.append(dict(command=list(command),check=dict(self.trajectory_diagnostic)))
        self.guard_diagnostic = dict(t=pose.t,kind='candidate',requested=list(original),
                                     accepted=[0.,0.],rejected=rejected,safe=False)
        return (0.,0.),[]

    def step(self, now, enabled=True, signal_valid=True, ready=True, emergency=False):
        """检查输入和通道，连续限速，再验证 MPPI 的真实待执行动作。"""
        self.tracking_requested = False
        dt = .02 if self.last_tick is None else clamp(now-self.last_tick,.001,.10)
        self.last_tick = now
        if emergency:
            return self.halt('ESTOP','ESTOP','用户急停')
        if not enabled:
            self.stall_since,self.progress_pose = None,None
            self.progress_failed,self.observing_since = False,None
            return self.halt('PAUSED','PAUSED','跟随已暂停')
        if not ready:
            return self.halt('INITIALIZING','NOT_READY','姿态准备中或异常')
        if not signal_valid or self.target_stamp is None or not 0 <= now-self.target_stamp <= self.target_timeout:
            return self.halt('TARGET_LOST','TARGET_INVALID','UWB 数据无效或过期')
        if not self.history.values or not 0 <= now-self.history.values[-1].t <= .2:
            return self.halt('ODOM_LOST','ODOM_STALE','里程计数据过期')
        pose = self.history.values[-1]
        self.grid.recenter(pose.x,pose.y)
        if not self.grid.confirmed:
            return self.halt('WAITING','START_UNCONFIRMED','请先暂停并确认起始周围 1.2 m 净空')
        if self.grid.last_depth is None or not 0 <= now-self.grid.last_depth <= self.depth_timeout:
            return self.halt('WAITING','MAP_STALE','前视深度缺失或过期')
        free,allowed,_ = self.grid.layers(now)
        self.footprint = self.grid.footprint_status(pose.x,pose.y,now)
        if self.footprint['code'] != 'CLEAR':
            return self.halt('WAITING',self.footprint['code'],'机身包络净空不足，查看阻塞栅格诊断')
        velocity = np.asarray(self.target_velocity)
        target = np.asarray(self.target)+velocity*min(now-self.target_stamp,.2)
        distance = float(np.linalg.norm(target-[pose.x,pose.y]))
        self.last_distance = distance
        if distance < .85:
            return self.halt('TOO_CLOSE','TARGET_TOO_CLOSE','目标进入近距离保护区')
        speed = float(np.linalg.norm(velocity))
        spacing = self.desired_distance+.3*min(speed,.7)
        arrival_distance = spacing+FOLLOW_REGION_HALF_WIDTH+FOLLOW_GOAL_TOLERANCE
        if distance <= arrival_distance and speed < .08 and self.grid.segment_clear(free,[pose.x,pose.y],target):
            # 保持原地只要求当前完整包络安全，以及人与机器人间的视线已确认无障碍。
            # 把整条视线都按机器人包络膨胀，会在目标旁的未知格阻止正常保持并反复重发已完成动作。
            self.stall_since,self.progress_pose = None,None
            self.observing_since = None
            return self.halt('HOLDING','FOLLOW_DISTANCE','目标停下，保持舒适间距')
        if self.progress_failed:
            return self.halt('WAITING','NO_PROGRESS','本轮探索无进展，请暂停后再恢复以重新尝试')
        if self.plan.kind == 'OBSERVING' and self.observation.plan is None:
            # 观察的路径用途依赖区域和阶段元数据，任务被清空后旧路径必须同步失效。
            self.invalidate_plan('OBSERVATION_CONTEXT_LOST',now)
        # 进入区域观察前就验证当前运动能停在已知包络内；评估阶段也不能跳过实测停车保护。
        actual_safe,_ = self.braking_safe(pose,(self.motion[0],self.motion[2]),allowed,actual=True)
        if not actual_safe:
            return self.halt('WAITING','BRAKING_SPACE','实测运动的停车空间不足')
        # 有限前视避免把移动跟随区域当成一串停车终点；目标意图不作为自由空间证据。
        reference = None
        if self.use_follow_intent:
            reference = self.prepare_intent_reference(now,pose,spacing)
            if reference is None or reference.status != 'FRESH':
                code = 'FOLLOW_TRAIL_INVALID' if reference is None else 'FOLLOW_TRAIL_HISTORY_LOST'
                self.invalidate_plan(code,now)
                return self.halt('WAITING',code,'目标轨迹意图失效，请暂停后重新建立跟随意图')
        self.update_plan(pose,target+velocity*1.2,velocity,spacing,now,parking_safe=actual_safe,
                         intent_reference=reference)
        if not self.plan.path:
            return self.halt('WAITING',self.plan.reason if self.future is None else 'PLAN_PENDING','等待可执行通道')
        route = self.path_ahead(pose,allowed)
        if not route:
            self.invalidate_plan('PATH_INVALID',now)
            return self.halt('WAITING','PATH_INVALID','路径与最新地图冲突，重新搜索')
        if self.plan.kind == 'OBSERVING':
            if self.observing_since is None:
                self.observing_since = now
            elif now-self.observing_since > 40.:
                # 连续观察必须有总预算；大量与通行无关的新自由格不能无限延长墙前探索。
                self.progress_failed = True
                return self.halt('WAITING','NO_PROGRESS','观察预算已用尽，请暂停后再恢复以重新尝试')
        else:
            self.observing_since = None
        if self.observation.stage == 'EVALUATE':
            return self.halt('OBSERVING','OBSERVATION_EVALUATING','等待当前朝向的新深度，确认通道')
        if self.progress_pose is None or math.dist(self.progress_pose[:2],[pose.x,pose.y]) > .2 or int(allowed.sum()) > self.progress_pose[2]+25:
            self.progress_pose,self.stall_since = [pose.x,pose.y,int(allowed.sum())],now
        if self.stall_since is not None and now-self.stall_since > 15:
            # 失败保持到明确的暂停/恢复；后续地图计数抖动不能自行重新启动。
            self.progress_failed = True
            return self.halt('WAITING','NO_PROGRESS','观察或绕行无进展，暂停后可重新尝试')
        self.tracking_requested = True
        self.phase = 'OBSERVING' if self.plan.kind == 'OBSERVING' else ('DETOUR' if len(self.plan.path)>2 else 'FOLLOWING')
        if not self.external_active or not 0 <= now-self.external_stamp <= .3:
            return self.halt('WAITING','CONTROLLER_STALE','等待有效 MPPI 轨迹输出')
        forward,turn = self.external_command
        if not all(math.isfinite(v) for v in (forward,turn)):
            return self.halt('WAITING','CONTROLLER_INVALID','MPPI 返回非有限命令')
        if self.observation.stage == 'ORIENT':
            # 观察位置已到达；MPPI 的数值微小前进量不应在反复看向时累计成靠边漂移。
            forward = 0.
        # 距离需求和曲率共同限速，宽阔绕行不再固定降至 0.22 m/s。
        cap = min(.75,max(0.,speed+.6*max(0,distance-spacing)))
        curvature = abs(turn)/max(abs(forward),.12)
        cap = min(cap,math.sqrt(.45/max(curvature,.01)))
        if self.phase == 'OBSERVING':
            cap = min(cap,.45)
        self.speed_limit = cap
        desired = (clamp(forward,0.,cap),clamp(turn,-MAX_NAVIGATION_TURN,MAX_NAVIGATION_TURN))
        for i,(value,accel,jerk) in enumerate(zip(desired,(.6,1.6),(2.,4.))):
            request = clamp((value-self.command[i])/dt,-accel,accel)
            self.acceleration[i] += clamp(request-self.acceleration[i],-jerk*dt,jerk*dt)
            candidate = self.command[i]+self.acceleration[i]*dt
            if (value-self.command[i])*(value-candidate) <= 0:
                candidate,self.acceleration[i] = value,0.
            self.command[i] = (clamp(candidate,0.,cap) if i==0 else
                               clamp(candidate,-MAX_NAVIGATION_TURN,MAX_NAVIGATION_TURN))
        original = tuple(self.command)
        command,self.safety_path = self.constrain_command(pose,original,allowed)
        self.safety_limited = command != original
        for i in range(2):
            if command[i] != original[i]:
                self.acceleration[i] = 0.
        self.command = list(command)
        self.state,self.code = self.phase,'EXECUTION_LIMITED' if self.safety_limited else self.plan.reason
        self.reason = 'MPPI 连续跟踪；停车空间限速' if self.safety_limited else 'MPPI 沿已观测通道连续跟随'
        return command

    def diagnostics(self, now):
        """记录路径、原始 MPPI 命令和最终命令之间的约束原因。"""
        return dict(code=self.code,phase=self.phase,path=self.plan.path,plan_kind=self.plan.kind,
                    look_yaw=self.plan.look_yaw,safety_path=self.safety_path,plan_ms=self.plan_ms,
                    map=self.grid.display(now),tracker='nav2_mppi',motion=list(self.motion),
                    raw_command=list(self.external_command),speed_limit=self.speed_limit,
                    footprint=self.footprint,plan_revision=self.plan_revision,
                    search_pending=self.future is not None,controller_active=self.external_active,
                    controller_age=None if not math.isfinite(self.external_stamp) else now-self.external_stamp,
                    rejected_plan_count=self.rejected_plan_count,rejected_plan_reason=self.rejected_plan_reason,
                    execution_guard=self.guard_diagnostic,
                    halt_counts=dict(self.halt_counts),halt_events=list(self.halt_events),
                    follow_intent=self.intent_diagnostic,
                    observation=self.observation.diagnostics())
