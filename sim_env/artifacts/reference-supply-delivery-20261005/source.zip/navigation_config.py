"""跨搜索、控制与终点判断共享的仿真配置，不代表实机标定参数。"""

# 搜索的舒适距离带与 MPPI 位置容差必须一起用于上层到达判定。
# 否则控制器已到终点，上层仍催促前进，会不断重发厘米级路径。
FOLLOW_REGION_HALF_WIDTH = .22
FOLLOW_GOAL_TOLERANCE = .08
# 连续跟随参考尽量覆盖一个 MPPI 预测窗口及下一次搜索间隔；只是软偏好，不封死短通道。
MPPI_HORIZON_SECONDS = 2.4
PLAN_UPDATE_SECONDS = .4
FOLLOW_REFERENCE_SHORTFALL_COST = 2.
# 该距离只用于参考点接近及无收益终点的失败判定；观察准入由实际位置的区域与视野验证决定。
OBSERVATION_POSITION_TOLERANCE = FOLLOW_GOAL_TOLERANCE
OBSERVATION_YAW_TOLERANCE = .20
# rate 独立物理对照在前速 0 / 0.3 / 0.5 下验证了 ±0.4 rad/s 换向。
# 优化器与最终命令共用这个已测实验范围；输入限幅 ±1 不表示机身能实现 1 rad/s。
MAX_NAVIGATION_TURN = .4
