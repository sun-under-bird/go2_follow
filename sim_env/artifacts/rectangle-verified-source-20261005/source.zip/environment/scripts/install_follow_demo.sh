#!/usr/bin/env bash
# 安装连续跟随源码和入口，复用 Python/ROS/MuJoCo 与发行版 Nav2，不编译 ROS 包。
set -Eeuo pipefail
script_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
sim_root="$HOME/go2_sim"
[[ -x "$sim_root/venv/bin/python" && -f "$sim_root/setup.bash" ]] || { echo '请先完成基础仿真环境安装'; exit 1; }
for binary in /opt/ros/humble/lib/nav2_controller/controller_server /opt/ros/humble/lib/nav2_lifecycle_manager/lifecycle_manager; do
    [[ -x "$binary" ]] || { echo "缺少 Nav2 运行程序：$binary。请先按环境文档安装 ROS 2 Humble Navigation2。"; exit 1; }
done
[[ -f /opt/ros/humble/share/nav2_mppi_controller/critics.xml ]] || { echo '缺少 ros-humble-nav2-mppi-controller 运行包'; exit 1; }
mkdir -p "$sim_root/follow_demo" "$sim_root/bin"
cp -r "$script_dir/../follow_demo/." "$sim_root/follow_demo/"
cat > "$sim_root/bin/go2-follow" <<'EOF'
#!/usr/bin/env bash
# 演示使用独立 DDS 域，避免与原生仿真检查或其他开发任务串话。
source "$HOME/go2_sim/follow_demo/setup.bash"
export MUJOCO_GL="${MUJOCO_GL:-osmesa}"
cd "$HOME/go2_sim"
exec python -m follow_demo.app "$@"
EOF
chmod +x "$sim_root/bin/go2-follow"
echo '已安装：go2-follow；浏览器地址 http://localhost:8765'
