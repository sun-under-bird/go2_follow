"""D435i 红外双目的简化几何配置；安装位置和实际设备标定仍待实测。"""
import math

# 采用 D435i 所用 D430 深度模组的约 50 mm 基线与约 58° 垂直视场。
# 分辨率选 424×240，理想针孔的水平视场约 88.8°；不是某台设备导出的内参。
WIDTH, HEIGHT = 424, 240
FOVY, BASELINE = 58.0, 0.050
HFOV = math.degrees(2 * math.atan(WIDTH / HEIGHT * math.tan(math.radians(FOVY / 2))))

# 原点为双目中点，机身坐标为前 x、左 y、上 z；此安装位置是待测占位值。
CAMERA_CENTER = (0.23, 0.025, 0.135)


def camera_position(side):
    """按双目中点计算左右光心位置，让 MJCF 和 ROS TF 使用同一份外参。"""
    sign = {'left': 1, 'right': -1}[side]
    x, y, z = CAMERA_CENTER
    return [x, y + sign * BASELINE / 2, z]
