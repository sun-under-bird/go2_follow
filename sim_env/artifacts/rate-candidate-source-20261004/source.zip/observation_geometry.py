"""从传感器地图验证观察几何；预测未知格与实际地图变化采用相同世界格编号。"""
import math
from functools import lru_cache
import numpy as np


# 仅观察姿态使用的仿真工程余量，尚未由实机转向漂移测量标定。
OBSERVATION_DRIFT_MARGIN = .10
OBSERVATION_MIN_GAIN = .10
OBSERVATION_MIN_OVERLAP = .30
OBSERVATION_REGION_RADIUS = .35


def observation_attempted(tried, point, heading, resolution=.1):
    """按已执行的区域与视向去重；旧三项记录仍按原单点半径识别。"""
    cell = tuple(math.floor(value/resolution) for value in point)
    for attempt in tried:
        difference = (heading-attempt[2]+math.pi) % (2*math.pi)-math.pi
        if abs(difference) >= .35:
            continue
        if len(attempt) >= 4:
            # 区域准入允许在参考点之前停下，去重也必须覆盖同一任务的完整区域。
            # 只比较原区域的世界格，不把附近其他位置或不同朝向一并封锁。
            if any(tuple(math.floor(value/resolution) for value in position) == cell
                   for position in attempt[3]):
                return True
        elif math.dist(point,attempt[:2]) < .2:
            return True
    return False


def world_cells(grid, rows, cols):
    """将窗口内行列转成固定世界格编号，滚动窗口移动不改变同一地面的身份。"""
    mask = np.zeros(grid.size*grid.size,dtype=bool)
    mask[rows*grid.size+cols] = True
    return world_cells_from_mask(grid,mask)


def world_cells_from_mask(grid, mask):
    """仅在对外返回所选视野时组装世界格，内部评分不创建 Python 坐标集合。"""
    offset = np.rint(grid.origin/grid.resolution).astype(int)
    flat = np.flatnonzero(mask)
    return set(zip((flat%grid.size+offset[0]).tolist(),(flat//grid.size+offset[1]).tolist()))


def local_cell_mask(grid, selected_cells):
    """将相关世界格映射至当前窗口；窗口外格不出现于mask，但仍保留在上层重叠分母。"""
    mask = np.zeros(grid.size*grid.size,dtype=bool)
    selected = np.asarray(list(selected_cells),dtype=int)
    if not len(selected):
        return mask
    local = selected-np.rint(grid.origin/grid.resolution).astype(int)
    inside = (local[:,0] >= 0) & (local[:,0] < grid.size) & (local[:,1] >= 0) & (local[:,1] < grid.size)
    local = local[inside]
    mask[local[:,1]*grid.size+local[:,0]] = True
    return mask


@lru_cache(maxsize=4)
def ray_samples(resolution):
    """缓存半格间距的前视覆盖，最远处横向间距和径向步长都不超过半格。"""
    step = resolution*.5
    count = math.ceil(1.36*3.1/step)+1
    angles = np.linspace(-.68,.68,count)
    ranges = np.linspace(0.,3.1,math.ceil(3.1/step)+1)
    return angles,ranges


def observation_masks(grid, free, points, headings, include_visible=True):
    """同时覆盖少量视野并用格mask去重，保留密射线逐线遮挡语义，避免集合与排序。"""
    points = np.asarray(points,dtype=float).reshape(-1,2)
    headings = np.asarray(headings,dtype=float).reshape(-1)
    count = len(points)
    offsets,ranges = ray_samples(grid.resolution)
    angles = headings[:,None]+offsets[None,:]
    # 分别计算行列，减少临时 xy/indices 三维数组；连续位置与朝向不量化、不缓存旧地图结果。
    col = np.floor((points[:,0,None,None]+np.cos(angles)[:,:,None]*ranges-grid.origin[0])/grid.resolution).astype(int)
    row = np.floor((points[:,1,None,None]+np.sin(angles)[:,:,None]*ranges-grid.origin[1])/grid.resolution).astype(int)
    valid = (col >= 0) & (col < grid.size) & (row >= 0) & (row < grid.size)
    np.clip(col,0,grid.size-1,out=col)
    np.clip(row,0,grid.size-1,out=row)
    # 射线一旦遇到已知障碍或窗口外，后面的未知不能被虚构成可观察收益。
    blocked = grid.occupied[row,col] | ~valid
    # 第一个障碍表面本身可见，但其后方不可见；未知不能凭空作为遮挡物或自由格。
    previous_blocked = np.cumsum(blocked,axis=2)-blocked
    visible = (previous_blocked == 0) & valid
    # 近于 0.7 m 的覆盖只负责发现遮挡；收益仍来自原 0.7~3.1 m 范围。
    eligible = visible & (ranges >= .7-1e-9)
    # 每视野分配一个连续格mask，重复采样写同一 True，替代三次 np.unique 排序。
    flat = row*grid.size+col+np.arange(count)[:,None,None]*(grid.size*grid.size)
    covered = np.zeros((count,grid.size*grid.size),dtype=bool)
    covered.ravel()[flat[eligible]] = True
    unknown = covered & (~free & ~grid.occupied).ravel()[None,:]
    covered_count = np.count_nonzero(covered,axis=1)
    gains = np.count_nonzero(unknown,axis=1)/np.maximum(1,covered_count)
    visible_mask = None
    if include_visible:
        visible_mask = np.zeros_like(covered)
        visible_mask.ravel()[flat[visible]] = True
    return dict(gains=gains,unknown_masks=unknown,visible_masks=visible_mask,
                covered_counts=covered_count,ray_count=len(offsets),sample_count=len(offsets)*len(ranges))


def observation_gains(grid, free, points, headings):
    """分批仅计算候选数值收益，限制临时内存；物理覆盖与最终观察验证使用同一核心。"""
    points,headings = np.asarray(points),np.asarray(headings)
    gains = np.empty(len(points))
    # 十六视野批次在 0.1 m 地图约 8.7 万采样，不一次构造全部 128 视野的临时数组。
    for begin in range(0,len(points),16):
        end = begin+16
        gains[begin:end] = observation_masks(grid,free,points[begin:end],headings[begin:end],False)['gains']
    return gains


def observation_view(grid, free, point, heading):
    """按地图分辨率覆盖原前视扇区，返回唯一世界格上的未知比例及可见格集合。"""
    view = observation_masks(grid,free,[point],[heading])
    return dict(gain=float(view['gains'][0]),
                unknown_cells=world_cells_from_mask(grid,view['unknown_masks'][0]),
                visible_cells=world_cells_from_mask(grid,view['visible_masks'][0]),
                covered_count=int(view['covered_counts'][0]),ray_count=view['ray_count'],sample_count=view['sample_count'])


def unknown_world_cells(grid, free, point, heading):
    """获取当前视向预测待揭示的世界格；它们只是预测，不能计作已经观测的信息。"""
    return observation_view(grid,free,point,heading)['unknown_cells']


def check_observation_position(grid, point, heading, expected_cells, now):
    """验证实际连续位置的净空、预测收益及原前沿覆盖；搜索连通性仍由上层验证。"""
    free,_,clearance = grid.layers(now)
    view = observation_view(grid,free,point,heading)
    expected = set(map(tuple,expected_cells))
    overlap = view['visible_cells'] & expected
    ratio = len(overlap)/max(1,len(expected))
    cell = grid.cell(*point)
    margin = grid.radius+grid.resolution*math.sqrt(.5)+OBSERVATION_DRIFT_MARGIN
    distance = 0. if cell is None else float(clearance[cell])
    if cell is None:
        reason = 'OBSERVATION_OUTSIDE_MAP'
    elif not free[cell] or distance < margin:
        reason = 'OBSERVATION_NO_DRIFT_SPACE'
    elif ratio < OBSERVATION_MIN_OVERLAP:
        reason = 'OBSERVATION_FRONTIER_MISMATCH'
    elif view['gain'] < OBSERVATION_MIN_GAIN:
        reason = 'OBSERVATION_LOW_GAIN'
    else:
        reason = 'OBSERVATION_POSITION_VALID'
    # 使用可见格而非仍未知格计算重叠：移动中已揭示的相关格不应因变已知而丢失身份。
    return dict(valid=reason == 'OBSERVATION_POSITION_VALID',
                geometry_valid=reason in ('OBSERVATION_POSITION_VALID','OBSERVATION_LOW_GAIN'),reason=reason,
                gain=view['gain'],overlap_ratio=ratio,overlap_count=len(overlap),
                clearance=distance,unknown_cells=view['unknown_cells'],visible_cells=view['visible_cells'])


def observation_cell_state(grid, selected_cells, now):
    """统计指定世界格的真实已知、自由、可通行和障碍状态，不把预测收益当测量。"""
    result = dict(known=set(),free=set(),allowed=set(),occupied=set())
    selected = np.asarray(sorted(set(map(tuple,selected_cells))),dtype=int)
    if not len(selected):
        return result
    offset = np.rint(grid.origin/grid.resolution).astype(int)
    local = selected-offset
    inside = np.all((local >= 0) & (local < grid.size),axis=1)
    selected,local = selected[inside],local[inside]
    if not len(selected):
        return result
    cols,rows = local[:,0],local[:,1]
    free,allowed,_ = grid.layers(now)
    occupied = grid.occupied[rows,cols]
    # 障碍表面也是真实新信息；已知不意味着自由，更不意味着完整包络可通行。
    known = (np.isfinite(grid.seen[rows,cols]) & (grid.seen[rows,cols] <= now)) | occupied
    masks = dict(known=known,free=free[rows,cols],allowed=allowed[rows,cols],occupied=occupied)
    for name,mask in masks.items():
        result[name] = set(map(tuple,selected[mask].tolist()))
    return result
