# 本演示及外部观察节点使用相同 DDS 域和图像传输配置。
source "$HOME/go2_sim/setup.bash"
export ROS_DOMAIN_ID=42
export CYCLONEDDS_URI="file://$HOME/go2_sim/follow_demo/cyclonedds.xml"
# 小矩阵投影与多个 ROS 进程并行时，限制数值库线程，避免线程争抢拖慢控制回调。
export OPENBLAS_NUM_THREADS=1
export OMP_NUM_THREADS=1
export MKL_NUM_THREADS=1
