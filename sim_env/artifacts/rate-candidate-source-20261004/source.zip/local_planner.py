"""已知通道上的滚动进展搜索；确实缺少可走通道时才选择观察任务。"""
from dataclasses import dataclass, field
import heapq
import math
import numpy as np
from .controller import wrap
from .navigation_config import FOLLOW_REGION_HALF_WIDTH, OBSERVATION_POSITION_TOLERANCE
from .observation_geometry import (OBSERVATION_DRIFT_MARGIN, OBSERVATION_MIN_GAIN,
                                   OBSERVATION_MIN_OVERLAP, OBSERVATION_REGION_RADIUS, observation_view,
                                   observation_gains, observation_masks, local_cell_mask, observation_attempted)


OBSERVATION_CANDIDATE_BUDGET = 32


@dataclass
class Plan:
    """一段可执行路线及其终点用途，观察目标不等于跟随目标。"""
    kind: str = 'WAITING'
    reason: str = 'NO_SAFE_CORRIDOR'
    path: list = field(default_factory=list)
    look_yaw: float = 0.0
    target: list = field(default_factory=list)
    observation_region: list = field(default_factory=list)
    observation_cells: list = field(default_factory=list)


class LocalPlanner:
    """一次 Dijkstra 搜索同时比较跟随区域与观察位置，适合多终点局部问题。"""
    def __init__(self):
        """记住上次路线，避免观测小幅变化就左右换边。"""
        self.previous = Plan()
        self.side = 0

    def search(self, grid, allowed, clearance, pose, target, velocity, spacing, tried=()):
        """依次搜索舒适距离带、已知通道进展和观察姿态，所有执行路径均来自安全连通区。"""
        start = grid.cell(pose.x, pose.y)
        if start is None or not allowed[start]:
            return Plan(reason='FOOTPRINT_UNOBSERVED')
        distances = np.full(allowed.shape, np.inf)
        distances[start] = 0.0
        parents, queue = {}, [(0.0, start)]
        steps = [(a,b,grid.resolution*math.hypot(a,b)) for a in (-1,0,1) for b in (-1,0,1) if a or b]
        distance_from_body = clearance.astype(float)-grid.radius
        margin = distance_from_body-grid.resolution*math.sqrt(.5)
        # 净空只取决于目的格，提前计算同一因子，避免八邻接内重复标量 max/sqrt。
        # 仍保留目的格有向代价及原 allowed，不能借提速放松未知与斜穿角的边界。
        weights = 1.+.18/np.maximum(.06,margin)+2.*np.maximum(0.,.15-margin)
        while queue:
            cost, cell = heapq.heappop(queue)
            if cost > distances[cell]:
                continue
            row, col = cell
            for dr,dc,length in steps:
                other = row + dr, col + dc
                if not (0 <= other[0] < grid.size and 0 <= other[1] < grid.size and allowed[other]):
                    continue
                if dr and dc and not (allowed[row + dr, col] and allowed[row, col + dc]):
                    continue
                # 安全格内优先宽通道；不足额外 0.15 m 舒适余量时增加代价，不破坏安全可达性。
                new_cost = cost+length*weights[other]
                if new_cost < distances[other]:
                    distances[other], parents[other] = new_cost, cell
                    heapq.heappush(queue, (new_cost, other))
        cells = np.argwhere(np.isfinite(distances))
        points = grid.origin + (cells[:, ::-1] + 0.5) * grid.resolution
        travel = distances[cells[:, 0], cells[:, 1]]
        target = np.asarray(target)
        speed = np.linalg.norm(velocity)
        direction = np.asarray(velocity) / speed if speed > 0.15 else target - [pose.x, pose.y]
        direction = direction / max(np.linalg.norm(direction), 1e-6)
        desired = target - spacing * direction
        separation = np.linalg.norm(points - target, axis=1)
        goals = np.abs(separation - spacing) <= FOLLOW_REGION_HALF_WIDTH
        target_bearing = math.atan2(target[1] - pose.y, target[0] - pose.x)
        end_margin = margin[cells[:,0],cells[:,1]]
        if np.any(goals):
            # 首要任务是沿现有通道接近跟随区域；刚转弯时不能为抢占人的正后方反向绕圈。
            score = 1.3 * travel + 0.30 * np.linalg.norm(points - desired, axis=1)
            # 不为满足精确间距把终点放到墙角边缘；净空是软偏好，窄通道仍可通行。
            score += .22/np.maximum(.08,end_margin+.08)
            if self.previous.path:
                score += 0.25 * np.linalg.norm(points - self.previous.path[-1], axis=1)
            score[~goals] = np.inf
            selected = int(np.argmin(score))
            result = Plan('FOLLOWING', 'FOLLOW_REGION_REACHABLE', target=target.tolist())
        else:
            # 人的舒适距离带暂时不可达，不代表已看清的前方通道不能继续走。
            # 先选安全连通区内的滚动进展终点；未知只决定后续观察需求，绝不加入执行路径。
            selected = self.progress_candidate(points,travel,separation,pose,target,end_margin)
            if selected is not None:
                result = Plan('FOLLOWING','KNOWN_CORRIDOR_PROGRESS',target=target.tolist())
            else:
                return self.search_observation(grid,allowed,clearance,pose,target,cells,points,travel,
                                               separation,parents,start,target_bearing,tried,weights)
        return self.make_path(grid,allowed,pose,result,cells,parents,start,selected,target_bearing,weights)

    def search_observation(self, grid, allowed, clearance, pose, target, cells, points, travel,
                           separation, parents, start, target_bearing, tried, weights):
        """通道无法取得足够进展时才寻找观察姿态，保持真实自由空间的执行边界。"""
        # 观察候选也是已知自由区域内的机器人中心，不能把未知格子作为可行驶终点。
        candidates = self.observation_candidates(grid,cells,points,travel,separation,clearance,pose)
        if not len(candidates):
            # 路径仍可使用原 allowed；只有停下转向的位置需要额外漂移空间。
            return Plan(reason='NO_ROBUST_OBSERVATION')
        best, selected, look = math.inf, None, pose.yaw
        free, _, _ = grid.layers(pose.t)
        views,view_points,view_headings = [],[],[]
        for index in candidates:
            point = points[index]
            bearing = math.atan2(target[1] - point[1], target[0] - point[0])
            travel_heading = math.atan2(point[1]-pose.y,point[0]-pose.x)
            # 当前执行器不主动倒退：观察位置在身后时必须支付转身、再转回观察的代价。
            # 忽略这一点会在几乎到达后反复选择后方几十厘米处，把连续通道变成掉头任务。
            move_turn = (abs(wrap(travel_heading-pose.yaw))
                         if math.dist(point,[pose.x,pose.y]) > OBSERVATION_POSITION_TOLERANCE else 0.)
            for heading in (bearing, bearing + 0.8, bearing - 0.8, pose.yaw):
                if observation_attempted(tried,point,heading,grid.resolution):
                    continue
                views.append((index,bearing,heading,move_turn))
                view_points.append(point)
                view_headings.append(heading)
        # 候选评分只要数值收益，批量计算中不创建数百个世界格 tuple/set。
        gains = observation_gains(grid,free,view_points,view_headings)
        for (index,bearing,heading,move_turn),gain in zip(views,gains):
            if gain < OBSERVATION_MIN_GAIN:
                continue
            point = points[index]
            # 只追求未知面积会转去观察与通行无关的一侧；向目标方向的视野优先。
            # 侧向仍保留收益，允许绕墙端点，目标方位不直接抢占执行转向。
            useful_gain = gain*(.35+.65*max(0.,math.cos(wrap(heading-bearing))))
            lateral = math.sin(wrap(math.atan2(point[1]-pose.y,point[0]-pose.x)-target_bearing))
            switch_cost = 0.7 if self.side and lateral*self.side < -0.2 else 0.0
            score = 0.35*travel[index]+0.65*separation[index]-2.2*useful_gain+0.15*abs(wrap(heading-pose.yaw))+.45*move_turn+switch_cost
            if self.previous.kind == 'OBSERVING' and self.previous.path:
                score += 0.35*math.dist(point,self.previous.path[-1])
            if score < best:
                best,selected,look = score,int(index),heading
        if selected is None:
            return Plan(reason='NO_USEFUL_OBSERVATION')
        result = Plan('OBSERVING', 'GOAL_UNOBSERVED', look_yaw=wrap(look), target=target.tolist())
        view = observation_view(grid,free,points[selected],result.look_yaw)
        result.observation_cells = [list(cell) for cell in sorted(view['unknown_cells'])]
        result.observation_region = self.observation_region(grid,allowed,clearance,cells,points,
                                                            points[selected],result.look_yaw,view['unknown_cells'],free)
        if not result.observation_region:
            return Plan(reason='NO_ROBUST_OBSERVATION')
        return self.make_path(grid,allowed,pose,result,cells,parents,start,selected,target_bearing,weights)

    def make_path(self, grid, allowed, pose, result, cells, parents, start, selected, target_bearing, weights):
        """沿已知安全搜索树回溯并简化路径，跟随和观察共享同一包络校验。"""
        cell = tuple(cells[selected])
        route = [grid.point(cell)]
        while cell != start:
            cell = parents[cell]
            route.append(grid.point(cell))
        route.reverse()
        route[0] = [pose.x, pose.y]
        # 用同一口径的线段离散代价比较原路线和候选捷径。
        # 只查不碰障碍会把 Dijkstra 的宽通道重新拉直到墙角，抹掉搜索的净空偏好。
        cumulative = np.zeros(len(route))
        edge_peak = np.zeros(max(0,len(route)-1))
        for j,(a,b) in enumerate(zip(route,route[1:])):
            cost,edge_peak[j] = self.segment_metrics(grid,allowed,weights,a,b)
            cumulative[j+1] = cumulative[j]+cost
        if not np.isfinite(cumulative[-1]):
            return Plan(reason='PATH_CONNECTION_UNKNOWN')
        result.path = [route[0]]
        index = 0
        while index < len(route) - 1:
            end = len(route) - 1
            while end > index+1:
                original = cumulative[end]-cumulative[index]
                shortcut,peak = self.segment_metrics(grid,allowed,weights,route[index],route[end])
                # 在原路线具备空间时保留至少 0.20 m 舒适余量；本来就窄的通道不被切断。
                # 只限制后处理不能把通道挤窄，不把这项舒适偏好变成新的全图硬膨胀。
                peak_limit = max(1.+.18/.20,float(np.max(edge_peak[index:end])))
                if shortcut <= original*1.005+1e-9 and peak <= peak_limit+1e-9:
                    break
                end -= 1
            result.path.append(route[end])
            index = end
        if result.path and len(result.path) > 1:
            first = result.path[1]
            lateral = math.sin(wrap(math.atan2(first[1] - pose.y, first[0] - pose.x) - target_bearing))
            if abs(lateral) > 0.3:
                self.side = 1 if lateral > 0 else -1
        self.previous = result
        return result

    @staticmethod
    def segment_metrics(grid, allowed, weights, a, b):
        """返回线段代理代价与最差格权重，总代价和局部净空均不能被拉直抹掉。"""
        cells = grid.segment_cells(a,b)
        if cells is None:
            return math.inf,math.inf
        indices = np.asarray(cells,dtype=int)
        if not np.all(allowed[indices[:,0],indices[:,1]]):
            return math.inf,math.inf
        # 这是统一的离散代理代价，触角格按平均权重计入，不能当作精确连续积分。
        values = weights[indices[:,0],indices[:,1]]
        return math.dist(a,b)*float(np.mean(values)),float(np.max(values))

    def progress_candidate(self, points, travel, separation, pose, target, margin):
        """选择有实际前进长度的已知通道终点，避免落后后进入更慢的观察循环。"""
        offsets = points-[pose.x,pose.y]
        length = np.linalg.norm(offsets,axis=1)
        current_separation = math.dist([pose.x,pose.y],target)
        relative = np.arctan2(offsets[:,1],offsets[:,0])-pose.yaw
        angles = np.abs((relative+math.pi)%(2*math.pi)-math.pi)
        # 至少留出一段移动参考，过滤厘米级边界点；长度不足时停车观察仍是正常出口。
        # 前向锥仅约束这个过渡目标，目标在身后且缺少已知路线时先观察，禁止盲退。
        candidates = (length >= .8) & (travel <= 3.8) & (angles <= 1.05)
        candidates &= separation <= current_separation-.35
        if not np.any(candidates):
            return None
        score = separation+.20*travel+.15*angles+.22/np.maximum(.08,margin+.08)
        if self.previous.kind == 'FOLLOWING' and self.previous.path:
            score += .12*np.linalg.norm(points-self.previous.path[-1],axis=1)
        score[~candidates] = np.inf
        return int(np.argmin(score))

    @staticmethod
    def observation_region(grid, allowed, clearance, cells, points, center, heading, expected_cells, free):
        """构造同一视向下有足够收益且覆盖原前沿的连通位置集合，不用距离容差代替观察。"""
        threshold = grid.radius+grid.resolution*math.sqrt(.5)+OBSERVATION_DRIFT_MARGIN
        nearby = np.flatnonzero((np.linalg.norm(points-center,axis=1) <= OBSERVATION_REGION_RADIUS)
                               & (clearance[cells[:,0],cells[:,1]] >= threshold))
        region = set()
        expected_mask = local_cell_mask(grid,expected_cells)
        # 区域仍逐格检验相同物理视野，内部直接与mask相交；分母包含窗口外相关格。
        for begin in range(0,len(nearby),16):
            indices = nearby[begin:begin+16]
            views = observation_masks(grid,free,points[indices],np.full(len(indices),heading))
            overlap = np.count_nonzero(views['visible_masks'] & expected_mask,axis=1)/max(1,len(expected_cells))
            valid = (views['gains'] >= OBSERVATION_MIN_GAIN) & (overlap >= OBSERVATION_MIN_OVERLAP)
            region.update(map(tuple,cells[indices[valid]]))
        start = grid.cell(*center)
        if start not in region:
            return []
        # 邻近距离不能证明连通；仍以原安全格和禁止斜穿角的规则保留中心所在分量。
        reached,queue = {start},[start]
        while queue:
            row,col = queue.pop()
            for dr in (-1,0,1):
                for dc in (-1,0,1):
                    other = row+dr,col+dc
                    if not (dr or dc) or other not in region or other in reached:
                        continue
                    if dr and dc and not (allowed[row+dr,col] and allowed[row,col+dc]):
                        continue
                    reached.add(other)
                    queue.append(other)
        return [grid.point(cell) for cell in sorted(reached)]

    @staticmethod
    def observation_candidates(grid, cells, points, travel, separation, clearance, pose):
        """细化粗采样附近与近身视点，限定收益评估预算，同时排除不稳定的转向边缘。"""
        threshold = grid.radius+grid.resolution*math.sqrt(.5)+OBSERVATION_DRIFT_MARGIN
        local_clearance = clearance[cells[:,0],cells[:,1]]
        robust = np.flatnonzero((travel < 4.) & (local_clearance >= threshold))
        if not len(robust):
            return np.array([],dtype=int)
        distance = np.linalg.norm(points-[pose.x,pose.y],axis=1)
        priority = .35*travel+.65*separation
        coarse = robust[(cells[robust,0] % 3 == 0) & (cells[robust,1] % 3 == 0)]
        # 十六个粗网格代表先占位，保留绕墙两侧与较远通道；细化点不能再次挤掉它们。
        seeds = coarse[np.argsort(priority[coarse],kind='stable')[:16]]
        nearest = int(robust[np.argmin(distance[robust])])
        nearby = robust[distance[robust] <= .5]
        # 当前位置只在满足漂移余量时保留；附近高净空格不能因 mod3 相位被遗漏。
        # 最近点、四个近身前沿与三个高净空点最多占八席；限制局部密集采样的份额。
        near_priority = nearby[np.argsort(priority[nearby],kind='stable')[:4]]
        near_stable = nearby[np.lexsort((distance[nearby],-local_clearance[nearby]))[:3]]
        local = np.unique(np.concatenate(([nearest],near_priority,near_stable)))
        required = np.unique(np.concatenate((local,seeds)))
        expanded = set(required.tolist()) | set(nearby.tolist())
        lookup = {tuple(cell):index for index,cell in enumerate(cells)}
        robust_set = set(robust.tolist())
        # 0.30 m 粗采样的相邻格加入 0.10 m 精细视点，始终只取原安全连通区。
        for index in seeds:
            row,col = cells[index]
            for dr in (-1,0,1):
                for dc in (-1,0,1):
                    candidate = lookup.get((row+dr,col+dc))
                    if candidate in robust_set:
                        expanded.add(candidate)
        remaining = np.array(sorted(expanded-set(required.tolist())),dtype=int)
        order = remaining[np.argsort(priority[remaining],kind='stable')]
        return np.concatenate((required,order[:OBSERVATION_CANDIDATE_BUDGET-len(required)]))

    @staticmethod
    def information_gain(grid, free, point, heading):
        """估计前视扇区可能新增的未知区域；射线到已知障碍终止，不读取真实场景。"""
        return float(observation_gains(grid,free,[point],[heading])[0])
