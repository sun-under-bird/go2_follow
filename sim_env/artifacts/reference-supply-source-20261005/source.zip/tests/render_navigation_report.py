"""把物理验收样本画成离线轨迹图；场景真值只用于报告，不参与导航。"""
import argparse
import json
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Circle, Rectangle
from follow_demo.scenarios import SCENARIOS

# 本机导出图采用中文字体；Linux 复现时允许回退到已安装的中文字体。
matplotlib.rcParams['font.sans-serif'] = ['Microsoft YaHei','Noto Sans CJK SC','SimHei','DejaVu Sans']
matplotlib.rcParams['axes.unicode_minus'] = False

def main():
    """读取已有证据，不启动仿真；展示真实行走路线与最后停车位置。"""
    parser = argparse.ArgumentParser()
    parser.add_argument('--directory', type=Path, default=Path.home() / 'go2_sim/artifacts')
    parser.add_argument('--prefix', default='navigation-v2')
    args = parser.parse_args()
    fig, axes = plt.subplots(2, 3, figsize=(13, 8), constrained_layout=True)
    titles = {'open': '开阔通道', 'long_wall': '长横向障碍', 'consecutive': '连续交错障碍',
              'corner': '直角盲弯', 'blocked': '封闭通道'}
    for ax, (name, scene) in zip(axes.flat, SCENARIOS.items()):
        report_path = args.directory / f'{args.prefix}-{name}.json'
        samples_path = args.directory / f'{args.prefix}-{name}-samples.json'
        if not report_path.exists() or not samples_path.exists():
            ax.set_title(titles[name] + ' / 无记录')
            continue
        report, samples = json.loads(report_path.read_text(encoding='utf-8-sig')), json.loads(samples_path.read_text(encoding='utf-8-sig'))
        # 灰色箱体是验收时已知的仿真真值，仅解释走到了哪里，不代表控制器曾看见整张图。
        for x, y, sx, sy, _ in scene['boxes']:
            ax.add_patch(Rectangle((x - sx, y - sy), 2 * sx, 2 * sy, color='#687783', alpha=.7))
        if samples:
            ax.plot([r['target'][0] for r in samples], [r['target'][1] for r in samples],
                    '--', color='#d1873e', label='目标实际路线')
            ax.plot([r['x'] for r in samples], [r['y'] for r in samples], color='#168b8b', lw=2, label='机器人实际路线')
            final = samples[-1]
            ax.plot(final['x'], final['y'], 'x', color='#b74444', ms=9, label='最终位置')
            ax.add_patch(Circle((final['x'], final['y']), .48, fill=False, color='#b74444', alpha=.6))
        passed = report.get('passed_navigation', False)
        ax.set_title(titles[name] + (' / 通过' if passed else ' / 未通过'), fontsize=11)
        ax.text(.02, .02, report.get('final_code', report.get('error', 'No record')), transform=ax.transAxes, fontsize=8)
        # 开阔路线持续前进，范围必须包含目标，不能截掉跟随距离让图像看起来已追上。
        far_x = max((max(r['x'],r['target'][0]) for r in samples),default=8)+1
        ax.set(xlim=(-1,max(10,far_x) if name == 'open' else 9), ylim=(-2.5, 3.5), xlabel='x (m)', ylabel='y (m)')
        ax.set_aspect('equal')
        ax.grid(alpha=.2)
    handles, labels = axes.flat[0].get_legend_handles_labels()
    axes.flat[-1].axis('off')
    axes.flat[-1].legend(handles, labels, loc='upper left')
    axes.flat[-1].text(0, .45, '灰色障碍真值仅用于解释报告\n没有碰撞不等于完成绕障\n每场单次最终回归，不代表成功率\n控制器：Nav2 MPPI + 统一执行保护',
                      transform=axes.flat[-1].transAxes, fontsize=10, linespacing=1.8)
    fig.suptitle('前视相机局部导航：真实物理轨迹验收', fontsize=15)
    fig.savefig(args.directory / f'{args.prefix}-trajectories.png', dpi=160)
    fig.savefig(args.directory / f'{args.prefix}-trajectories.svg')
    plt.close(fig)
    print(args.directory / f'{args.prefix}-trajectories.png')

    # 同时展示整段速度，不截去转弯停车或人停止之后的保持时段。
    fig,axes = plt.subplots(5,1,figsize=(12,12),constrained_layout=True)
    for ax,name in zip(axes,SCENARIOS):
        path = args.directory/f'{args.prefix}-{name}-samples.json'
        if not path.exists():
            continue
        rows = json.loads(path.read_text(encoding='utf-8-sig'))
        if not rows:
            continue
        times = [r['t']-rows[0]['t'] for r in rows]
        for label,key,color in [('实际机身前进速度','vx','#168b8b'),('目标速度','target_speed','#d1873e')]:
            ax.plot(times,[r.get(key,0) for r in rows],label=label,color=color,lw=1.5)
        ax.plot(times,[r['command'][0] for r in rows],label='最终前进指令',color='#657fa1',alpha=.65)
        ax.set(title=titles[name],ylabel='m/s',xlabel='开始跟随后仿真时间（s）',ylim=(-.05,.85))
        ax.grid(alpha=.2)
    axes[0].legend(loc='upper right',ncol=3)
    fig.savefig(args.directory/f'{args.prefix}-speeds.png',dpi=150)
    plt.close(fig)


if __name__ == '__main__':
    main()
